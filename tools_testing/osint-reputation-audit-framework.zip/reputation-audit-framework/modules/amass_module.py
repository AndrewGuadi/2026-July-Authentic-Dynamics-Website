"""OWASP Amass collector — passive subdomain enumeration only.

``-passive`` is hard-coded: Amass only queries third-party data sources
(certificate transparency, passive DNS, public archives). Brute forcing,
zone walking and active resolution are never enabled by this module.
"""
from __future__ import annotations

import math
from typing import Any, List

from core.runner import run_command
from core.validator import Scope
from core.workspace import Workspace
from modules.base import ModuleResult, OSINTModule
from normalization.normalize_domains import from_amass

FORBIDDEN_FLAGS = {"-active", "-brute", "-w", "-rf", "-p"}


class AmassModule(OSINTModule):
    """Enumerate the client's public attack surface from passive sources."""

    name = "amass"
    scope_field = "domain"
    category = "domain"
    passive = True
    description = "Passive subdomain/attack-surface enumeration via third-party datasets."

    @property
    def binary(self) -> str:
        """Native executable name."""
        return "amass"

    def run(self, scope: Scope, workspace: Workspace) -> ModuleResult:
        """Execute Amass in passive mode and return normalised domain findings."""
        domain = self.target_value(scope)
        if not domain:
            return ModuleResult.skipped(self.name, "no domain in scope")
        if not self.options.get("passive_only", True):
            return ModuleResult.skipped(
                self.name,
                "refusing to run: module_options.amass.passive_only must remain true (passive-only policy)",
            )

        mode = self.execution_mode()
        blocked = self.unavailable(mode)
        if blocked:
            return blocked

        outdir = workspace.domain / "amass_raw"
        outdir.mkdir(parents=True, exist_ok=True)
        minutes = max(1, math.floor(self.timeout / 60))

        if mode == "docker":
            tool_args: List[str] = [
                "enum", "-passive", "-nocolor", "-d", domain,
                "-timeout", str(minutes), "-json", "/data/amass.json",
            ]
            command = self.docker_command(args=tool_args, volumes={outdir: "/data"})
        else:
            tool_args = [
                "enum", "-passive", "-nocolor", "-d", domain,
                "-timeout", str(minutes), "-json", str(outdir / "amass.json"),
            ]
            command = ["amass", *tool_args]

        if FORBIDDEN_FLAGS.intersection(tool_args):
            return ModuleResult.failed(self.name, "active Amass flags detected — execution aborted")

        self.log.info("amass passive enumeration for %s (%s)", domain, mode)
        result = run_command(command, timeout=self.timeout)
        raw_files = self.save_raw(workspace, result)

        payload: Any = self.load_json_file(outdir / "amass.json")
        if payload is None:
            payload = self.parse_json(result.stdout)
        if payload is None:
            status = "ok" if result.ok else "error"
            return ModuleResult(
                module=self.name,
                status=status,
                error=None if status == "ok" else (result.error or f"exit {result.returncode}"),
                note="no passive records returned" if status == "ok" else None,
                raw_files=raw_files,
                command=result.printable,
                execution=mode,
                duration=result.duration,
            )

        evidence = workspace.relative(outdir / "amass.json")
        findings = from_amass(payload=payload, apex=domain, evidence_file=evidence)
        return ModuleResult(
            module=self.name,
            status="ok",
            findings=findings,
            raw_files=raw_files + [evidence],
            command=result.printable,
            execution=mode,
            duration=result.duration,
            note=f"{len(findings)} unique hostname(s)",
        )
