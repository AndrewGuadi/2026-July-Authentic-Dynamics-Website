#!/usr/bin/env python3
"""reputation-audit-framework — passive OSINT reputation audit CLI.

Authorized-use only. This entry point performs argument parsing, prints the
legal disclaimer banner, enforces explicit authorization and then hands control
to :class:`core.orchestrator.Orchestrator`.

Example
-------
    python main.py run \\
        --full-name "Sarah Mitchell" \\
        --domain "sarahmitchellhomes.com" \\
        --username "sarahmitchellrealtor" \\
        --image-dir "./images" \\
        --authorized yes
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from core.banner import print_banner
from core.config import AppConfig, load_config
from core.orchestrator import Orchestrator
from core.validator import AuthorizationError, ScopeValidator, ValidationError

__version__ = "1.0.0"

app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    help="Passive OSINT reputation audit framework for authorized engagements.",
)
console = Console()

ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / "config.yaml"


@app.command("run")
def run(
    full_name: str = typer.Option(..., "--full-name", help="Client legal/brand name (audit subject)."),
    domain: Optional[str] = typer.Option(None, "--domain", help="Client-owned domain in scope."),
    username: Optional[str] = typer.Option(None, "--username", help="Primary handle to enumerate."),
    image_dir: Optional[Path] = typer.Option(
        None, "--image-dir", help="Directory of client-supplied images for metadata review."
    ),
    authorized: str = typer.Option(
        "no", "--authorized", help="Must be 'yes'. Written attestation that the scope is authorized."
    ),
    config_file: Path = typer.Option(DEFAULT_CONFIG, "--config", "-c", help="Path to config.yaml."),
    output_dir: Optional[Path] = typer.Option(None, "--output-dir", "-o", help="Override output root."),
    engagement_id: Optional[str] = typer.Option(None, "--engagement-id", help="Reference/ticket id for the report."),
    no_pdf: bool = typer.Option(False, "--no-pdf", help="Skip PDF rendering even if wkhtmltopdf exists."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate scope + config, print plan, execute nothing."),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose console logging (DEBUG)."),
) -> None:
    """Run a passive reputation audit against an authorized scope."""
    print_banner(console)

    try:
        config: AppConfig = load_config(config_file)
    except (FileNotFoundError, ValueError) as exc:
        console.print(f"[bold red]config error:[/bold red] {exc}")
        raise typer.Exit(code=2)

    validator = ScopeValidator(config)
    try:
        validator.require_authorization(authorized)
        scope = validator.build_scope(
            full_name=full_name,
            domain=domain,
            username=username,
            image_dir=image_dir,
            engagement_id=engagement_id,
        )
    except AuthorizationError as exc:
        console.print(f"[bold red]AUTHORIZATION REQUIRED:[/bold red] {exc}")
        console.print("Re-run with [bold]--authorized yes[/bold] only if you hold written permission.")
        raise typer.Exit(code=3)
    except ValidationError as exc:
        console.print(f"[bold red]scope error:[/bold red] {exc}")
        raise typer.Exit(code=2)

    orchestrator = Orchestrator(
        config=config,
        scope=scope,
        output_root=output_dir or Path(config.output_root),
        console=console,
        verbose=verbose,
        render_pdf=not no_pdf,
    )

    if dry_run:
        orchestrator.print_plan()
        raise typer.Exit(code=0)

    summary = orchestrator.execute()
    orchestrator.print_summary(summary)
    raise typer.Exit(code=0 if summary["status"] == "completed" else 1)


@app.command("modules")
def modules(
    config_file: Path = typer.Option(DEFAULT_CONFIG, "--config", "-c", help="Path to config.yaml."),
) -> None:
    """List registered modules, their scope requirements and enabled state."""
    from modules import MODULE_REGISTRY

    config = load_config(config_file)
    table = Table(title="Registered modules", header_style="bold green")
    table.add_column("Module")
    table.add_column("Enabled")
    table.add_column("Scope input")
    table.add_column("Execution")
    table.add_column("Passive")
    for name, cls in sorted(MODULE_REGISTRY.items()):
        enabled = config.modules.get(name, False)
        table.add_row(
            name,
            "[green]yes[/green]" if enabled else "[dim]no[/dim]",
            cls.scope_field,
            config.execution.get(name, config.default_execution),
            "[green]passive[/green]" if cls.passive else "[red]active[/red]",
        )
    console.print(table)


@app.command("doctor")
def doctor() -> None:
    """Report which local binaries / container runtimes are available."""
    from core.runner import binary_available, docker_available

    table = Table(title="Environment check", header_style="bold green")
    table.add_column("Dependency")
    table.add_column("Status")
    checks = {
        "docker": docker_available(),
        "maigret": binary_available("maigret"),
        "blackbird": binary_available("blackbird"),
        "amass": binary_available("amass"),
        "exiftool": binary_available("exiftool"),
        "trufflehog": binary_available("trufflehog"),
        "theHarvester": binary_available("theHarvester"),
        "wkhtmltopdf": binary_available("wkhtmltopdf"),
    }
    for dep, ok in checks.items():
        table.add_row(dep, "[green]available[/green]" if ok else "[yellow]missing (docker fallback)[/yellow]")
    console.print(table)


@app.command("version")
def version() -> None:
    """Print the framework version."""
    console.print(f"reputation-audit-framework {__version__}")


def main() -> None:
    """Console-script wrapper."""
    try:
        app()
    except KeyboardInterrupt:  # pragma: no cover - interactive path
        console.print("\n[yellow]Interrupted by operator. Partial output retained.[/yellow]")
        sys.exit(130)


if __name__ == "__main__":
    main()
