# reputation-audit-framework

A modular, containerised **passive OSINT reputation audit** framework for authorized
engagements — built for security practices auditing their own clients (real estate
agents, small businesses, solo professionals).

> **Passive reconnaissance only.** No authentication bypass. No CAPTCHA solving.
> No paywall circumvention. No brute force. No intrusive scanning.

---

## Table of contents

1. [What it does](#what-it-does)
2. [Installation](#installation)
3. [Docker setup](#docker-setup)
4. [Usage](#usage)
5. [Configuration](#configuration)
6. [Output structure](#output-structure)
7. [Normalised finding schema](#normalised-finding-schema)
8. [Risk heuristic engine](#risk-heuristic-engine)
9. [Sample output](#sample-output)
10. [Extension guide](#extension-guide)
11. [Legal disclaimer template](#legal-disclaimer-template)

---

## What it does

| Stage | Component | Description |
| --- | --- | --- |
| Gate | `core/validator.py` | Refuses to run without `--authorized yes`; validates and records scope |
| Workspace | `core/workspace.py` | Creates `output/{client}_{date}/…` evidence tree |
| Collection | `modules/*` | Runs each enabled tool natively or as an ephemeral container |
| Normalisation | `normalization/*` | Converts every tool output into one canonical JSON schema |
| Scoring | `core/risk.py` | Deterministic, config-driven heuristics → Low / Moderate / Elevated / High |
| Reporting | `reporting/*` | Markdown executive report + structured JSON + optional PDF |
| Audit trail | `core/logger.py` | JSON-lines structured log at `logs/audit.log` |

**Integrated collectors**

| Module | Tool | Scope input | Purpose |
| --- | --- | --- | --- |
| `maigret` | Maigret | `--username` | Public account presence across OSINT-indexed sites |
| `blackbird` | Blackbird | `--username` | Second-source corroboration of handle presence |
| `amass` | OWASP Amass (`-passive`) | `--domain` | Passive subdomain / attack-surface enumeration |
| `spiderfoot` | SpiderFoot (allowlisted modules) | `--domain` | Multi-source passive OSINT correlation |
| `exiftool` | ExifTool | `--image-dir` | EXIF/IPTC/XMP metadata + GPS leakage review |
| `trufflehog` *(plugin)* | TruffleHog | `--image-dir` | Secret detection in client-supplied assets |
| `theharvester` *(plugin)* | theHarvester | `--domain` | Hostnames / published addresses from passive feeds |

Plugins are registered but **disabled by default** in `config.yaml`.

---

## Installation

### One command (Linux / macOS)

```bash
git clone <your-fork> reputation-audit-framework
cd reputation-audit-framework
./install.sh            # creates .venv, installs deps, checks collectors
source .venv/bin/activate
python main.py doctor
```

Requirements: **Python 3.11+**. Optional native collectors (`exiftool`, `amass`,
`maigret`, `wkhtmltopdf`) are auto-detected; anything missing falls back to Docker
when `execution: auto` or `docker` is configured.

### Manual

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python main.py --help
```

---

## Docker setup

```bash
# 1. Build the application image
docker compose build audit

# 2. Pull the collector images (one time)
docker compose --profile tools pull

# 3. Run an audit inside the container
docker compose run --rm audit run \
  --full-name "Sarah Mitchell" \
  --domain "sarahmitchellhomes.com" \
  --username "sarahmitchellrealtor" \
  --image-dir "/app/images" \
  --authorized yes
```

Volumes mounted by `docker-compose.yml`:

| Host | Container | Mode | Purpose |
| --- | --- | --- | --- |
| `./output` | `/app/output` | rw | Evidence workspaces |
| `./images` | `/app/images` | ro | Client-supplied imagery |
| `./config.yaml` | `/app/config.yaml` | ro | Scan configuration |
| `/var/run/docker.sock` | `/var/run/docker.sock` | rw | Sibling-container collectors |

> Mounting the Docker socket grants the container control of the host daemon.
> Remove that line and set `execution: native` for every module if your threat
> model forbids it — the image ships ExifTool and Maigret natively.

---

## Usage

```bash
python main.py run \
  --full-name "Sarah Mitchell" \
  --domain "sarahmitchellhomes.com" \
  --username "sarahmitchellrealtor" \
  --image-dir "./images" \
  --authorized yes
```

If `--authorized` is anything other than `yes`, the tool prints the legal notice
and exits with code `3` **before any collection occurs**.

| Command | Description |
| --- | --- |
| `run` | Execute an audit against an authorized scope |
| `modules` | List registered modules, enabled state and execution mode |
| `doctor` | Report which binaries / runtimes are available |
| `version` | Print the framework version |

Useful `run` flags:

| Flag | Description |
| --- | --- |
| `--config, -c` | Alternate `config.yaml` |
| `--output-dir, -o` | Override the evidence root |
| `--engagement-id` | Attach your ticket / matter reference |
| `--dry-run` | Validate scope + print the plan, execute nothing |
| `--no-pdf` | Markdown only |
| `--verbose, -v` | DEBUG console logging |

Exit codes: `0` success · `1` completed with module errors · `2` invalid scope/config · `3` authorization missing · `130` interrupted.

---

## Configuration

`config.yaml` drives everything — no code changes required to tune a scan.

```yaml
modules:
  maigret: true
  blackbird: true
  amass: true
  spiderfoot: true
  exiftool: true

risk_thresholds:
  high: 8
  elevated: 5
  moderate: 3
```

Additional blocks: `execution` (native/docker/auto per module), `docker_images`,
`timeouts`, `module_options`, `risk_weights`, `risk_rules`, `reporting`, `logging`.

---

## Output structure

```
output/{client_slug}_{YYYY-MM-DD}/
    usernames/     domain/     images/
    logs/          normalized/ report/
    scope.json     summary.json
```

See [`examples/output-tree.txt`](examples/output-tree.txt) for a fully populated tree.

---

## Normalised finding schema

Every module emits the same record shape:

```json
{
  "type": "username",
  "source_tool": "maigret",
  "value": "https://example.social/sarahmitchellrealtor_official",
  "risk_hint": "impersonation_keyword",
  "evidence_file": "usernames/maigret_raw/report_simple.json",
  "timestamp": "2026-02-14T09:31:07+00:00",
  "details": { "site": "example.social", "status": "claimed" }
}
```

`type` ∈ `username | domain | image` · `risk_hint` ∈ `informational,
impersonation_keyword, gps_metadata, pii_metadata, subdomain_exposure, secret_exposure`.
`details` is additive context and is never used for scoring.

---

## Risk heuristic engine

| Rule | Points | Trigger |
| --- | ---: | --- |
| `impersonation_keyword` | +2 each (cap 6) | Discovered handle contains brand/impersonation keywords |
| `gps_metadata` | +3 | Published imagery retains GPS coordinates |
| `subdomain_exposure` | +2 | More than 10 unique hostnames in passive datasets |
| `secret_exposure` | +4 | Credential/secret material detected |
| `pii_metadata` | +1 | Author, owner or device serial retained in metadata |

Bands: `Low < 3` · `Moderate ≥ 3` · `Elevated ≥ 5` · `High ≥ 8` (all configurable).

---

## Sample output

```text
  ___ ___ ___ _   _ _____ _ _____ ___ ___  _  _
 | _ \ __| _ \ | | |_   _/_\_   _|_ _/ _ \| \| |
 |   / _||  _/ |_| | | |/ _ \| |  | | (_) | .` |
 |_|_\___|_|  \___/  |_/_/ \_\_| |___\___/|_|\_|
      A U D I T   F R A M E W O R K   v1.0.0

╭──────────────────────── LEGAL NOTICE ────────────────────────╮
│ AUTHORIZED USE ONLY — PASSIVE RECONNAISSANCE                 │
│ 1. You have documented, written permission …                 │
╰──────────────────────────────────────────────────────────────╯

▸ running maigret    → sarahmitchellrealtor
▸ running blackbird  → sarahmitchellrealtor
▸ running amass      → sarahmitchellhomes.com
▸ running spiderfoot → sarahmitchellhomes.com
▸ running exiftool   → /work/images

            Module results
┏━━━━━━━━━━━━┳━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━┓
┃ Module     ┃ Status  ┃ Findings ┃ Seconds ┃
┡━━━━━━━━━━━━╇━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━┩
│ maigret    │ ok      │       14 │    62.4 │
│ blackbird  │ ok      │        9 │    41.8 │
│ amass      │ ok      │       17 │    93.1 │
│ spiderfoot │ ok      │       23 │   140.6 │
│ exiftool   │ ok      │       12 │     3.2 │
└────────────┴─────────┴──────────┴─────────┘

╭──────────── Engagement RAF-20260214-093107 ─────────────╮
│ Risk score: 9   Band: High                              │
│ Findings: {"total": 75, "username": 23, "domain": 40,   │
│            "image": 12}                                 │
│ Report: output/sarah_mitchell_2026-02-14/report/report.md│
╰─────────────────────────────────────────────────────────╯
```

A complete rendered deliverable lives in
[`examples/EXAMPLE_REPORT.md`](examples/EXAMPLE_REPORT.md).

---

## Extension guide

Adding a collector takes three steps.

**1 — Implement the module** (`modules/mytool_module.py`):

```python
from core.runner import run_command
from modules.base import ModuleResult, OSINTModule
from normalization.schema import make_finding


class MyToolModule(OSINTModule):
    """One-line description used in reports."""

    name = "mytool"          # must match the config.yaml key
    scope_field = "domain"   # domain | username | image_dir
    category = "domain"      # username | domain | image
    passive = True

    @property
    def binary(self) -> str:
        return "mytool"

    def run(self, scope, workspace) -> ModuleResult:
        target = self.target_value(scope)
        if not target:
            return ModuleResult.skipped(self.name, "no domain in scope")

        mode = self.execution_mode()
        if (blocked := self.unavailable(mode)):
            return blocked

        command = (
            self.docker_command(["--target", target], volumes={workspace.domain: "/out"})
            if mode == "docker"
            else ["mytool", "--target", target]
        )
        result = run_command(command, timeout=self.timeout)
        raw_files = self.save_raw(workspace, result)

        findings = [
            make_finding("domain", self.name, row, "informational", raw_files[0])
            for row in (self.parse_json(result.stdout) or [])
        ]
        return ModuleResult(
            module=self.name, status="ok", findings=findings, raw_files=raw_files,
            command=result.printable, execution=mode, duration=result.duration,
        )
```

**2 — Register it** in `modules/__init__.py`:

```python
from modules.mytool_module import MyToolModule
MODULE_REGISTRY[MyToolModule.name] = MyToolModule
MODULE_ORDER = (*MODULE_ORDER, "mytool")
```

**3 — Enable it** in `config.yaml`:

```yaml
modules:
  mytool: true
execution:
  mytool: auto
docker_images:
  mytool: org/mytool:latest
timeouts:
  mytool: 600
module_options:
  mytool:
    depth: 1
```

Verify with `python main.py modules` and `python main.py run … --dry-run`.

**Rules for new modules**

- Passive sources only — if it authenticates, brute forces or solves CAPTCHAs, it does not ship.
- Never raise; return `ModuleResult.failed(...)` or `ModuleResult.skipped(...)`.
- Always persist raw evidence via `self.save_raw(...)` and reference it in each finding.
- Emit findings through `normalization.schema.make_finding` so scoring stays consistent.

---

## Legal disclaimer template

Copy into your engagement letter and have the client sign before the first run.

```text
AUTHORIZATION FOR PASSIVE OPEN-SOURCE REPUTATION ASSESSMENT

Client:            ____________________________________________
Authorised signer: ____________________________________________
Assessor:          ____________________________________________
Engagement ID:     ____________________________________________
Window:            ______________  to  ______________

The Client authorises the Assessor to perform a PASSIVE open-source
intelligence assessment of the following assets, which the Client warrants
it owns or is otherwise entitled to have assessed:

  Domain(s):   ____________________________________________
  Handle(s):   ____________________________________________
  Image set:   ____________________________________________

The Assessor will:
  1. Collect only publicly available information.
  2. Not bypass authentication, paywalls, CAPTCHAs or access controls.
  3. Not perform brute-force, credential testing or intrusive scanning.
  4. Not interact with third parties on the Client's behalf.
  5. Record scope, operator identity and UTC collection timestamps.
  6. Store findings confidentially and delete them after ____ days.

Findings describe publicly observable data at the time of collection and are
provided without warranty. The Client remains responsible for remediation.

Client signature: ______________________  Date: ______________
Assessor signature: ____________________  Date: ______________
```

---

## Security notes

- Evidence may contain personal data — treat `output/` as confidential and encrypt at rest.
- Container output is written as the invoking UID/GID so evidence is never root-owned.
- Secret values found by the TruffleHog plugin are stored as redacted fingerprints, never in full.
- Commands are executed as argument vectors (no shell), so scope values cannot inject commands.
- Review `logs/audit.log` — it is the authoritative record of what was collected and when.

## License

Released for authorized professional use. Add your organisation's license before distribution.
